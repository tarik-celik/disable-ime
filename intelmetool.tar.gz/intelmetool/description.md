Dump interesting things about Management Engine even if hidden `C`
